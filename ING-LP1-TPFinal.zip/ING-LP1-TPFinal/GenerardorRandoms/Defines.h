#pragma once
#include <string>
using namespace std;

#define CantidadNombres 100
#define CantidadDNI 100
#define CandidadDireccionParadas 50

string DefineNombres[];
string DefineDNI[];
string DefineDireccionParadas[];