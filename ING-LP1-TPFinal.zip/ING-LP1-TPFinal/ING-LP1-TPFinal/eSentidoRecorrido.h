#pragma once
#include <string>
#include <iostream>

using namespace std;

enum class eSentidoRecorrido { Arriba = 0, Abajo };

//inline string SentidoToString(eSentidoRecorrido sentido) {
//	switch (sentido)
//	{
//	case eSentidoRecorrido::Arriba:
//		return"Arriba";
//		break;
//	case eSentidoRecorrido::Abajo:
//		return"Abajo";
//		break;
//	default:
//		return "";
//		break;
//	}
//}